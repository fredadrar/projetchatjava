package controler;

import modele.PostBean;

public class Controler {
	private Ihm ihm;

	private void refreshSreen() {
		boolean pseudoLabelVisible = true;
		boolean pseudoBarreVisible = true;
		boolean pseudoBtnVisible = true;
		boolean chatWindowVisible = false;
		boolean userListVisible = false;
		boolean inputBarreVisible = false;
		boolean btnRefreshVisible = false;
		boolean btnSendVisible = false;

	}

	public void sendPost() {

	}

	public void clickRefresh() {

	}

	public void clickSend(PostBean post) {

	}

	public void setIhm(Ihm ihm) {
		this.ihm = ihm;
	}

}
