package modele;

import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class WsUtils {

	public static final String URL_SERVER = "192.168.x.x/projectChat/rest/WebService";
	public static final String GET_POST = URL_SERVER + "";
	public static final String GET_USER = URL_SERVER + "";
	public static final String SEND_POST = URL_SERVER + "";
	public static final String SEND_USER = URL_SERVER + "";

	public void sendPost(PostBean post) throws Exception {
		Gson gson = new Gson();
		String json = gson.toJson(post);
		OkHttpUtils.sendPostOk(SEND_POST, json);

	}

	public ArrayList getPosts() throws Exception {
		Gson gson = new Gson();
		String json = OkHttpUtils.sendGetOk(GET_POST);
		ArrayList<PostBean> list = gson.fromJson(json, new TypeToken<ArrayList<PostBean>>() {
		}.getType());
		return list;

	}

	public void sendUser(UserBean user) throws Exception {
		Gson gson = new Gson();
		String json = gson.toJson(user);
		OkHttpUtils.sendPostOk(SEND_USER, json);

	}

	public ArrayList getUsers() throws Exception {
		Gson gson = new Gson();
		String json = OkHttpUtils.sendGetOk(GET_USER);
		ArrayList<UserBean> list = gson.fromJson(json, new TypeToken<ArrayList<UserBean>>() {
		}.getType());
		return list;
	}

}
